package com.androidlover;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;

//------------------------FACEBOOK------------
//--------------------GOOGLE--------------


public class MainActivity extends AppCompatActivity {
    //private FirebaseAuth mFirebaseAuth;
    //private FirebaseAuth.AuthStateListener authStateListener;

   // String TAG1="Facebook sign in operation";

    GoogleSignInClient mGoogleSignInClient;
    int RC_SIGN_IN=0;
    SignInButton sign;

    //public MainActivity(CallbackManager mCallbackManager) {
    //}


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        sign=findViewById(R.id.sign_in_button);
        sign.setSize(SignInButton.SIZE_STANDARD);
        sign.setOnClickListener(v -> {
            if (v.getId() == R.id.sign_in_button) {
                signIn();
            }
        });
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
    }

    @Override
    public void onStart(){
        super.onStart();
    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            handleSignInResult();

        }
    }
    private void handleSignInResult() {

        // Signed in successfully, show authenticated UI.

        // Signed in successfully, show authenticated UI.
        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
        startActivity(intent);
    }


       /* public void onCreate() {
            FacebookSdk.sdkInitialize(getApplicationContext());
            AppEventsLogger.activateApp(this);
        }
    mFirebaseAuth= FirebaseAuth.getInstance();
    FacebookSdk.sdkInitialize(getApplicationContext());
        ImageView mlogo = findViewById(R.id.imageView2);
        LoginButton loginButton = findViewById(R.id.login_button);
        loginButton.setReadPermissions("email","public_profile");
    mCallbackManager = CallbackManager.Factory.create();

        loginButton.registerCallback(mCallbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                Log.d(TAG1,"onSuceess"+ loginResult);
                handleFacebookToken(loginResult.getAccessToken());
            }

            @Override
            public void onCancel() {
                Log.d(TAG1,"onCancle ");
            }

            @Override
            public void onError(FacebookException error) {
                Log.d(TAG1,"onCancle "+ error);
            }
            // App code

        });

        mCallbackManager = CallbackManager.Factory.create();


        LoginManager.getInstance().registerCallback(mCallbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        Log.d(TAG1,"onSuceess"+ loginResult);
                        handleFacebookToken(loginResult.getAccessToken());
                    }

                    @Override
                    public void onCancel() {

                    }

                    @Override
                    public void onError(FacebookException exception) {
                    }
                });
            authStateListener= firebaseAuth -> {
                FirebaseUser user=firebaseAuth.getCurrentUser();
                updateUI(user);
            };


    }

    private void handleFacebookToken(AccessToken token) {
        Log.d(TAG1,"handleFacebookToken"+token);
        AuthCredential credential= FacebookAuthProvider.getCredential(token.getToken());
        mFirebaseAuth.signInWithCredential(credential).addOnCompleteListener(this, task -> {
            if(task.isSuccessful()){
                Log.d(TAG1,"sign in with Credential:Success");
                FirebaseUser user= mFirebaseAuth.getCurrentUser();
                updateUI(user);
            }else{
                Log.d(TAG1,"Sign in with Credential : failure",task.getException());
                Toast.makeText(MainActivity.this,"Authentication Failed",Toast.LENGTH_LONG).show();
            }
        });
    }

    private void updateUI(FirebaseUser user) {
        if(user!=null){
            Intent intent = new Intent(MainActivity.this, MainActivity2.class);

            startActivity(intent);}
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        mCallbackManager.onActivityResult(requestCode,resultCode,data);
        super.onActivityResult(requestCode,resultCode,data);
    }
    @Override
    protected void onStart() {
        super.onStart();
        mFirebaseAuth.addAuthStateListener(authStateListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        mFirebaseAuth.removeAuthStateListener(authStateListener);

    }*/
}
