package com.androidlover;

import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;

public class MainActivity2 extends AppCompatActivity {
    ImageView imageView;
    TextView name, email, id;
    GoogleSignInClient mGoogleSignInClient;
    Button signout;
    //FirebaseAuth mFirebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        imageView = findViewById(R.id.imageView);
        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        id = findViewById(R.id.id);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        signout = findViewById(R.id.sign_out);
        signout.setOnClickListener(v -> {
            if (v.getId() == R.id.sign_out) {
                signOut();
            }
        });
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        if (acct != null) {
            String personName = acct.getDisplayName();
            String personEmail = acct.getEmail();
            String personId = acct.getId();
            Uri personPhoto = acct.getPhotoUrl();
            name.setText(personName);
            email.setText(personEmail);
            id.setText(personId);
            // imageView.setImageURI(personPhoto);
            //  Glide.with(this).load(String.valueOf(personPhoto)).into(imageView);
            //Glide.with(getApplicationContext()).load(String.valueOf(personPhoto)).into(imageView);
            Glide.with(this).load(String.valueOf(personPhoto)).apply(RequestOptions.circleCropTransform()).into(imageView);
        }
        /*
        FirebaseUser user= mFirebaseAuth.getCurrentUser();
        if(user!=null){
            String personName=user.getDisplayName();
            String personEmail=user.getEmail();
            String personId=user.getUid();
            Uri personPhoto=user.getPhotoUrl();
            name.setText(personName);
            email.setText(personEmail);
            id.setText(personId);
           Glide.with(this).load(String.valueOf(personPhoto)).apply(RequestOptions.circleCropTransform()).into(imageView);
        }
    }
    */

    }

    private void signOut() {
        mGoogleSignInClient.signOut()
                .addOnCompleteListener(this, task -> {
                    Toast.makeText(MainActivity2.this, "Sign Out Successfully...", Toast.LENGTH_LONG).show();
                    finish();
                });
    }
}